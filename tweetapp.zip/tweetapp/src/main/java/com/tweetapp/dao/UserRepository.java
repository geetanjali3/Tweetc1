package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tweetapp.model.UserModel;

public class UserRepository {
	Connection conn=DBConnection.getConnection();
	
	public boolean addUser(UserModel user) throws SQLException {
		if(conn!=null) {
			try {
				String query="Insert into user(firstName,lastName,email,gender,password,dob) values (?,?,?,?,?,?)";
				PreparedStatement stmt= conn.prepareStatement(query);
				stmt.setString(1, user.getFirstName());
				stmt.setString(2, user.getLastName());
				stmt.setString(3, user.getEmail());
				stmt.setString(4, user.getGender());
				stmt.setString(5, user.getPassword());
				stmt.setDate(6, user.getDob());
				stmt.execute();
				return true;
			}
			catch(Exception ex) {
				return false;
			}
		}
		return false;
	}
	
	public UserModel findbyId(String username) {
		UserModel user=null;
		if(conn!=null) {
			try {
			
				String query="Select * from user where email=?;";
				PreparedStatement stmt=conn.prepareStatement(query);
				stmt.setString(1, username);
				ResultSet quser=stmt.executeQuery();
				if(quser.next()) {
				user=new UserModel(quser.getString("firstName"),quser.getString("lastName"),
						quser.getString("email"),quser.getString("gender"),quser.getString("password"),quser.getDate("dob"));
				}
				return user;
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println(e);
				return user;
			}
		}
		return user;
	}
	public List<UserModel> findAll(){
		List<UserModel> users=new ArrayList<>();
		if(conn!=null) {
			try {
				Statement stmt=conn.createStatement();
				String query="Select * from user;";
				ResultSet quser=stmt.executeQuery(query);
				while(quser.next()) {
					UserModel user=new UserModel(quser.getString("firstname"),quser.getString("lastname"),
							quser.getString("email"),quser.getString("gender"),quser.getString("password"),quser.getDate("dob"));
				users.add(user);
				}
				return users;
				
			} catch (SQLException e) {
				e.printStackTrace();
				return users;
			}
		}
		return users;
	}
	
	public boolean updatePassword(UserModel user) {
		if(conn!=null) {
			try {
				String query="update user set password=? where email=?";
				PreparedStatement stmt=conn.prepareStatement(query);
				stmt.setString(1, user.getPassword());
				stmt.setString(2, user.getEmail());
				return stmt.execute();
			} catch (SQLException e) {
				System.out.println("unable to update password");
				return false;
			}
			
		}
		System.out.println("unable to update status");
		return false;
	}

}
