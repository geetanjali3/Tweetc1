package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tweetapp.model.TweetModel;

public class TweetRepository {
	Connection conn=DBConnection.getConnection();
	public boolean postTweet(TweetModel tweet) throws SQLException {
		if(conn!=null) {
			try {
				String query="insert into tweet(userName,tweet) values (?,?)";
				PreparedStatement stmt=conn.prepareStatement(query);
				stmt.setString(1, tweet.getUserId());
				stmt.setString(2, tweet.getTweet());
				return stmt.execute();
			}
			catch(Exception ex) {
				return false;
			}
		}
		return false;
	}
	public List<TweetModel> findAll(){
		List<TweetModel> tweets=new ArrayList<>();
		if(conn!=null) {
			try {
				Statement stmt=conn.createStatement();
				String query="select * from tweet";
				ResultSet result=stmt.executeQuery(query);
				while(result.next()) {
					TweetModel tweet=new TweetModel(result.getString("tweet"),result.getString("userName"));
					tweets.add(tweet);
				}
				return tweets;
			}
			catch(Exception ex) {
				return tweets;
			}
		}
		return tweets;
	}

}
