package com.tweetapp.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import com.tweetapp.dao.UserRepository;
import com.tweetapp.exception.TweetAppExceptionHandler;
import com.tweetapp.model.UserModel;
import com.tweetapp.service.UserLoginService;

public class UserLoginServiceImpl implements UserLoginService {

	UserRepository userRepository = new UserRepository();

	@Override
	public String register(UserModel userModel) {
		try {
			UserModel user = userRepository.findbyId(userModel.getEmail());
			if (user == null) {
				userRepository.addUser(userModel);
				return "Registration successful, Login in...";
			}
			throw new TweetAppExceptionHandler("User already registered, Login Now");
		} catch (Exception ex) {
			return ex.getMessage();
		}

	}

	@Override
	public boolean login(String username, String password) {
		try {
			UserModel user = userRepository.findbyId(username);
			if (user == null) {
				throw new TweetAppExceptionHandler("Username Not Found!! Please Register.");
			}
			if (user.getEmail().equalsIgnoreCase(username) && user.getPassword().equals(password)) {
				System.out.println("Login Successful!!");
				return true;
			}
			System.out.println("Incorrect Password, please try again!");
			return false;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}

	}

	@Override
	public List<String> viewAllUsers() {
		System.out.println("In user service to get all the users");
		return userRepository.findAll().stream().map(o -> o.getEmail()).collect(Collectors.toList());
	}
	@Override
	public boolean isPasswordMatch(String username, String enteredOldPassword) {
		try {
			UserModel user = userRepository.findbyId(username);
			if (user == null) {
				throw new TweetAppExceptionHandler("Username Not Found!!");
			}
			if (user.getPassword().equals(enteredOldPassword)) {
				return true;
			}
			throw new TweetAppExceptionHandler("Your Old password and entered Password Not Matched");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}

	}

	private void changePassword(String newPassword, UserModel user) {
		user.setPassword(newPassword);
		userRepository.updatePassword(user);
	}
	@Override
	public boolean resetPassword(String username, String oldPassword, String newPassword) {
		try {
			UserModel user = userRepository.findbyId(username);
			if (user == null) {
				throw new TweetAppExceptionHandler("Username Not Found!!");
			}
			if (user.getPassword().equals(oldPassword)) {
				changePassword(newPassword, user);
				return true;
			}
			throw new TweetAppExceptionHandler("Your Old password and entered Password Not Matched");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}

	}
	@Override
	public void forgotPassword(String username, String newPassword) {
		try {
			UserModel user = userRepository.findbyId(username);
			if (user == null) {
				throw new TweetAppExceptionHandler("Username Not Found!!");
			}
			changePassword(newPassword, user);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

	}

	@Override
	public boolean logout(String username) {
		try {
			UserModel user = userRepository.findbyId(username);
			if (user == null) {
				throw new TweetAppExceptionHandler("Username Not Found!!");
			}
			return true;

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}
	}

	@Override
	public boolean findUser(String userName) {
		try {
			UserModel user = userRepository.findbyId(userName);
			if (user == null) {
				throw new TweetAppExceptionHandler("Username Not Found!!");
			}
			else {
				return true;
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}
	}

}
