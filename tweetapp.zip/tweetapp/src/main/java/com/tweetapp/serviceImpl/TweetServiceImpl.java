package com.tweetapp.serviceImpl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.tweetapp.dao.TweetRepository;
import com.tweetapp.model.TweetModel;
import com.tweetapp.service.TweetService;

public class TweetServiceImpl implements TweetService {

	TweetRepository tweetRepository = new TweetRepository();

	@Override
	public String postATweet(TweetModel tweet) {
		try {
			tweetRepository.postTweet(tweet);
			return "Tweet added Successfully";
		} catch (Exception ex) {
			System.out.println("Failed to add tweet");
			return ex.getMessage();
		}

	}

	@Override
	public List<String> viewTweetByUser(String username) {
		System.out.println("getting your tweets");

		return tweetRepository.findAll().stream().filter(tweet -> tweet.getUserId().equals(username))
				.map(TweetModel::getTweet).collect(Collectors.toList());
	}

	@Override
	public Map<String, List<String>> viewTweetByAllUser() {
		System.out.println("getting user based tweets");
		return tweetRepository.findAll().stream().collect(Collectors.groupingBy(TweetModel::getUserId,
				Collectors.mapping(TweetModel::getTweet, Collectors.toList())));
	}

}
