package com.tweetapp.exception;

public class TweetAppExceptionHandler extends Exception{
    
	private static final long serialVersionUID = 1L;

	public TweetAppExceptionHandler(String message) {
        super(message);
    }
}
