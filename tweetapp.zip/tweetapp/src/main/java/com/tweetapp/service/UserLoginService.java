package com.tweetapp.service;

import java.util.List;

import com.tweetapp.model.UserModel;

public interface UserLoginService {
    String register(UserModel userDetails);
    boolean findUser(String userName);
    void forgotPassword(String username, String newPassword);
    boolean isPasswordMatch(String username, String enteredOldPassword);
    boolean login(String username,String password);
    boolean logout(String username);
    List<String> viewAllUsers();
    boolean resetPassword(String username,String old,String newPassword);
}
