package com.tweetapp;

import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.tweetapp.exception.TweetAppExceptionHandler;
import com.tweetapp.model.TweetModel;
import com.tweetapp.model.UserModel;
import com.tweetapp.service.TweetService;
import com.tweetapp.service.UserLoginService;
import com.tweetapp.serviceImpl.TweetServiceImpl;
import com.tweetapp.serviceImpl.UserLoginServiceImpl;

/**
 * Hello world!
 *
 */
public class App {
	static Scanner scanner = new Scanner(System.in);
	static boolean isUserLoggedIn = false;
	private static UserLoginService userService = new UserLoginServiceImpl();
	private static TweetService tweetService = new TweetServiceImpl();
	private static String username;

	public static void main(String[] args) {
		int choice;
		while (true) {
			System.out.println("--------------***Tweet App Menu***------------");
			if (!isUserLoggedIn) {
				System.out.println("1.Register\n2.Login\n3.Forgot Password");
				choice = Integer.parseInt(scanner.nextLine());
				switch (choice) {
				case 1:
					System.out.println(register());
					break;
				case 2:
					isUserLoggedIn = login();
					if (!isUserLoggedIn) {
						username = null;
					}
					else {
					System.out.println("Welcome " + username + " !!!");
					}
					break;
				case 3:
					forgotPassword();
					break;
				default:
					System.out.println("Enter the correct option");
				}
			} else {
				System.out.println(
						"1.Post a tweet\n2.View your tweets\n3.View all users\n4.View all users and thier Tweets\n5.Change Password\n6.Logout");
				choice = Integer.parseInt(scanner.nextLine());
				switch (choice) {
				case 1:
					System.out.println(postATweet(username));
					break;
				case 2:
					List<String> tweets = viewTweetByUser(username);
					if (tweets != null)
						tweets.forEach(System.out::println);
					else
						System.out.println("No tweets Found");
					break;

				case 3:
					List<String> users = viewAllUsers();
					if (users != null)
						users.forEach(System.out::println);
					else
						System.out.println("Sorry!! No users Found.");
					break;
				case 4:
					Map<String, List<String>> userTweet = viewAllUserTweet();
					for (String key : userTweet.keySet()) {
						System.out.println(key + "'s Tweets are: ");
						userTweet.get(key).forEach(System.out::println);
						System.out.println();
					}
					break;
				case 5:
					resetPassword(username);
					break;
				case 6:
					isUserLoggedIn = logOut();
					System.exit(0);
				default:
					System.out.println("**Please choose correct option**");
				}
			}
		}
	}

	private static String register() {
		UserModel userDetails = new UserModel();
		System.out.println("Enter your First Name:");
		String firstName = scanner.nextLine();
		if (firstName.matches("[A-Za-z]{3,15}$"))
			userDetails.setFirstName(firstName);
		else {
			System.out.println("Invalid first name!! Please enter a proper name between 3 to 15 characters");
			return "sorry!! Registration Failed.";
		}
		System.out.println("Enter your Last Name:");
		String lastName = scanner.nextLine();
		if (lastName.matches("[A-Za-z]{3,15}$"))
			userDetails.setLastName(lastName);
		else {
			System.out.println("Invalid last name!! Please enter a proper name between 3 to 15 characters");
			return "sorry!! Registration Failed.";
		}
		System.out.println("Enter Your Gender:");
		String gender = scanner.nextLine();
		if (gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female") || gender.equalsIgnoreCase("others")) {
			userDetails.setGender(gender);
		} else {
			System.out.println("Invalid Gender!! Please enter Male, Female or Others");
			return "sorry!! Registration Failed.";
		}
		System.out.println("Enter your Date of Birth in year-month-day format:");
		String dob = scanner.nextLine();
		try {
			userDetails.setDob(Date.valueOf(dob));
		} catch (Exception e) {
			System.out.println("**Invalid Date Format**");
			return "sorry!! Registration Failed.";
		}
		System.out.println("Enter User Name");
		String username = scanner.nextLine();
		String regex = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
		if (Pattern.compile(regex).matcher(username).matches()) {
			userDetails.setEmail(username);
		} else {
			System.out.println("Invalid Email!! Please enter proper email address as username.");
			return "sorry!! Registration Failed.";
		}
		System.out.println("Enter Password");
		String pass = scanner.nextLine();
		if (pass.length() < 8 || pass.length() > 20) {
			System.out.println(
					"Invalid Password!! Password must be more or equal to 8 characters and less than 20 characters");
			return "sorry!! Registration Failed.";
		}
		userDetails.setPassword(pass);
		return userService.register(userDetails);
	}

	public static boolean login() {
		System.out.println("In Login Method");
		System.out.println("Enter User Name");
		String userName = scanner.nextLine();
		System.out.println("Enter Password");
		String password = scanner.nextLine();
		if (userName == null || password == null || userName.trim().isEmpty() || password.trim().isEmpty()) {
			System.out.println("Login unsuccessful --> User name or password is empty");
			return false;
		} else {
			if (userService.findUser(userName)) {
			username = userName;
			return userService.login(username, password);
			}
			return false;
		}
	}

	public static String postATweet(String username) {
		TweetModel tweet = new TweetModel();
		tweet.setUserId(username);
		System.out.println("Enter your tweet:");
		tweet.setTweet(scanner.nextLine());
		return tweetService.postATweet(tweet);
	}

	public static List<String> viewAllUsers() {
		try {
			return userService.viewAllUsers();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return null;
		}
	}

	public static List<String> viewTweetByUser(String username) {
		try {
			return tweetService.viewTweetByUser(username);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return null;
		}
	}

	private static Map<String, List<String>> viewAllUserTweet() {
		return tweetService.viewTweetByAllUser();
	}

	private static void forgotPassword() {
		try {
		System.out.println("Enter your userName :");
		String userName = scanner.nextLine();
		if (userService.findUser(userName)) {
			System.out.println("Enter your new password");
			String newPassword = scanner.nextLine();
			if (newPassword.length() < 8 || newPassword.length() > 20) {
				System.out.println("Password should be between 8 to 20 characters");
				return;
			}
			System.out.println("Confirm your new password");
			String confirmPassword = scanner.nextLine();
			if (!newPassword.equals(confirmPassword)) {
				throw new TweetAppExceptionHandler("**New Password and Confirm Password should be the same**");
			}
				userService.forgotPassword(userName, newPassword);
				System.out.println("Your password has been changed successfully!!");
			
		}
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	public static void resetPassword(String username) {
		try {
			System.out.println("Enter your old password");
			String oldPassword = scanner.nextLine();
			if(!userService.isPasswordMatch(username, oldPassword))
				return;
			System.out.println("Enter your new password");
			String newPassword = scanner.nextLine();
			if (newPassword.length() < 8 || newPassword.length() > 20) {
				System.out.println("Password should be between 8 to 20 characters");
				return;
			}
			System.out.println("Confirm your new password");
			String newCheckPassword = scanner.nextLine();
			if (!newPassword.equals(newCheckPassword)) {
				throw new TweetAppExceptionHandler("**New Password and Confirm Password should be the same**");
			}
			if (newPassword.equals(oldPassword)) {
				throw new TweetAppExceptionHandler("**Old password and New password should not be the same**");
			}
			if (userService.resetPassword(username, oldPassword, newPassword)) {
				System.out.println("Your password has been changed successfully!!");
				return;
			}
			System.out.println("Sorry!! Failed to change Password.");
			return ;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return ;
		}
	}

	public static boolean logOut() {
		if (userService.logout(username)) {
			System.out.println("You've Logged out Successfully!!");
			return false;
		}
		System.out.println("Sorry!! Failed to logout.");
		return true;
	}
}
